import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { movies} from '../Movies';
@Component({
  selector: 'app-moviedetail',
  templateUrl: './moviedetail.component.html',
  styleUrls: ['./moviedetail.component.css']
})
export class MoviedetailComponent implements OnInit {
  id:any;
  movie:any=movies;
  singlemovie:any;

  constructor(private ar:ActivatedRoute) { }

  ngOnInit() {
    this.id=this.ar.snapshot.params['id'];
    this.singlemovie=this.movie.filter(
      movie => movie.id == this.id);
      console.log(this.singlemovie);
  }

}
