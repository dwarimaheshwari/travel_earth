import { Component, OnInit } from '@angular/core';
import { movies} from '../Movies';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
 movie:any=movies;
 moviefilter:any=movies;
 genre:string='All';
  constructor() { }

  ngOnInit() {
  }
  filterMovie(){
    if(this.genre=='All'){
      this.moviefilter=this.movie;
    }
    else{
      this.moviefilter=this.movie.filter(
        movie =>{ 
          for(let i=0;i<movie.genres.length;i++){
            if(movie.genres[i] == this.genre){
              return true;
            }
          }
          });
        console.log(this.moviefilter);
    }
  }

}
