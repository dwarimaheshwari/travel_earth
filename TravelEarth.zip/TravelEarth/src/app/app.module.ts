import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes } from '@angular/router';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { ListComponent } from './list/list.component';
import { MoviedetailComponent } from './moviedetail/moviedetail.component';

const appRoute:Routes=[
{path:"" ,component:ListComponent},
{path:"movie/:id",component:MoviedetailComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ListComponent,
    MoviedetailComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(appRoute)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
