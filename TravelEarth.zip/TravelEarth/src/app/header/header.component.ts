import { Component, OnInit } from '@angular/core';
import { movies} from '../Movies';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  name:string;
  movie:any=movies;
  singlemovie:any;
  status:string;
  constructor() { }

  ngOnInit() {
    
  }

  search(){
    this.singlemovie=this.movie.filter(
      movie => movie.name == this.name);
      console.log(this.singlemovie.length)
      if(this.singlemovie.length>0){
        this.status="found";
      }
      if(this.singlemovie.length==0){
        this.status="notfound";
      }
      console.log(this.status);
  }
  remove(){
    this.singlemovie="";
    this.status="";
  }

}
